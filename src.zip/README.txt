Minizinc compiler must be installed on the computer, and the PATH environment variable set up properly.

The following files need to be present and in the same directory:

firefighter_minizinc.py
firefighter_pulp.py
helper.py
firefighter.mzn
pipeline.py

Additionally, the following Python packages must be installed:

numpy
matplotlib
networkx
seaborn
pandas
minizinc
